#!/bin/bash

#$ -M kmukherj@nd.edu        #Email address for job notification
#$ -m abe		 # Send mail when job begins, ends and aborts
#$ -pe smp 1	 # Specify parallel environment and legal core size
#$ -q debug		 # Specify queue
#$ -N IRMOF-1	         # Specify job name

#module load xyz	         # Required modules

module load lammps 
module load gcc/8.3.0

lmp_linux < in.IRMOF-1 > out.IRMOF-1
